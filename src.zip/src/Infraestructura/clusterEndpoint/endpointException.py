# -*- coding: utf8 -*-
'''
Clase de excepción para el endpoint de la web
@author: Luis Barrios Hernández
@version: 1.0
'''

class EndpointException(Exception):
    pass
