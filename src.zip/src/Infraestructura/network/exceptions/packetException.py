# -*- coding: utf8 -*-
'''
Packet exception definitions
@author: Luis Barrios Hernández
@version 1.0
'''

class PacketException(Exception):
    """
    Packet exception class
    """
    pass
