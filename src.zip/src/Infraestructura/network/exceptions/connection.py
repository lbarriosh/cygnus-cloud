# -*- coding: utf8 -*-
'''
Connection exception definitions
@author: Luis Barrios Hernández
@version: 1.0
'''

class ConnectionException(Exception):
    """
    Connection exception class
    """
    pass
