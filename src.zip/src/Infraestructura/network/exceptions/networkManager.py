# -*- coding: utf8 -*-
'''
Network manager exception definitions
@author: Luis Barrios Hernández
@version: 1.0
'''
class NetworkManagerException(Exception):
    """
    Network manager exception class
    """
    pass
