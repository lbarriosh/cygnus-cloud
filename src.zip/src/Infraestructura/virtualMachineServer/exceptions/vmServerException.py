# -*- coding: utf8 -*-
'''
Created on Apr 29, 2013

@author: luis
'''
class VMServerException(Exception):
    """
    Clase de excepción que utiliza el servidor de máquinas virtuales
    """
    pass