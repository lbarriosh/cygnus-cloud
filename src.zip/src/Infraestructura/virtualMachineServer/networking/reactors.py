# -*- coding: utf8 -*-
'''
Created on Apr 25, 2013

@author: luis
'''
class MainServerPacketReactor():
    """
    Reactor del servidor de máquinas virtuales
    """
    
    def processClusterServerIncomingPackets(self, packet):
        raise NotImplementedError