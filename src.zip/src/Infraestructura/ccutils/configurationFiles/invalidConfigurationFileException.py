# -*- coding: utf8 -*-
'''
Clase de excepción para el lector de los ficheros de configuración
@author: Luis Barrios Hernández
@version: 1.0
'''

class InvalidConfigurationFileException(Exception):
    pass
