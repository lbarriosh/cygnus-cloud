# coding: utf8
from serverConnector.singletonServerConnector import Singleton
#Establecemos la conexión con el servidor principal
connector = Singleton.getInstance()
