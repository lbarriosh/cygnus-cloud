# -*- coding: utf-8 -*-

#Constantes usadas para realizar la conexión
#Contraseña root
rootPassword = '170590ucm'
#Ruta de los certificados
certificatesPath = "applications/CygnusCloud/static/Certificates" 
#Nombre de la base de datos
dbStatusName = "SystemStatusDB"
#Ruta del sql
dbStatusPath = "applications/CygnusCloud/modules/database/SystemStatusDB.sql"
#Nombre del usuario web
webUserName =  "websiteUser"
#Contraseña del usuario 
webUserPass = "cygnuscloud"
#Nombre del usuario de carga
updateUserName = "updateUser"
#Contraseña del usuario de carga
updateUserPass = "cygnuscloud"
#Ip del servidor principal
serverIp = "127.0.0.1"
#Puerto del servidor principal
serverPort = 9000
#Intervalo de actualización
statusInterval = 5
