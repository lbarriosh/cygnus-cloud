# -*- coding: utf8 -*-
'''
Network manager exception definitions
@author: Luis Barrios Hernández
@version: 1.0
'''
class NetworkManagerException(Exception):
    """
    NetworkManager exception class
    """
    pass
