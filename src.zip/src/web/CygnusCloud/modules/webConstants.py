# -*- coding: utf-8 -*-

#Constantes usadas para realizar la conexión
#Contraseña root
rootPassword = '170590ucm'
#Ruta de los certificados
certificatesPath = "applications/CygnusCloud/static/Certificates" 
#Nombre de la base de datos de estado
dbStatusName = "SystemStatusDB"
#Nombre de la base de datos de comandos
commandsDBName = "CommandsDB"
#Ruta del sql
dbStatusPath = "applications/CygnusCloud/modules/database/SystemStatusDB.sql"
#Nombre del usuario web
webUserName =  "CygnusCloud"
#Contraseña del usuario 
webUserPass = "cygnuscloud2012"
#Nombre del usuario de carga
updateUserName = "updateUser"
#Contraseña del usuario de carga
updateUserPass = "cygnuscloud"
#Ip del servidor principal
serverIp = "127.0.0.1"
#Puerto del servidor principal
serverPort = 9000
#Intervalo de actualización
statusInterval = 5
