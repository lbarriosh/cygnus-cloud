# -*- coding: utf-8 -*-
from gluon import *


from configuration import DBConfigurator
from gluon.tools import Auth
from webConstants import rootPassword
import os

print os.getcwd()



conf = DBConfigurator(rootPassword)
conf.createDatabase('CygnusCloudUserDB')
conf.addUser('CygnusCloud','cygnuscloud2012', 'CygnusCloudUserDB')
userDB = DAL('mysql://CygnusCloud:cygnuscloud2012@localhost/CygnusCloudUserDB',migrate_enabled=True, pool_size=0)


# Autentication
auth = Auth(userDB)
auth.define_tables(migrate = True)




#userDB.auth_user.email.requires = IS_NOT_IN_DB(userDB, userDB.auth_user.email)

userDB.define_table('Images',
            Field('VMId','integer' ),
            Field('name',length=20 ),
            Field('description',length=500 ),
            primarykey=['VMId'],migrate= True)


userDB.define_table('ClassGroup',
   Field('yearGroup','integer', 'reference auth_user'),
   Field('cod','integer','reference Subjects'),
   Field('curse','integer'),
   Field('curseGroup', length=1),
   primarykey=['cod'],migrate= True)

userDB.define_table('UserGroup',
   Field('userId',length = 512 ),
   Field('cod','integer','reference ClassGroup'),
   Field('curseGroup',length=1 ),
   primarykey=['cod','curseGroup','userId'],migrate= True)

userDB.define_table('Subjects',
   Field('code','integer'),
   Field('name',length=50),
   primarykey=['code'],migrate= True)



userDB.define_table('VMByGroup',
   Field('VMId','integer','reference Images'),
   Field('cod','integer','reference UserGroup'),
   Field('curseGroup',length=1 ),
   primarykey=['cod','curseGroup','VMId'],migrate= True)
